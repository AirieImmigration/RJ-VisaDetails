import "./App.css";
import DetailsPage from "./components/DetailsPage";

function App() {
  return (
    <div>
      <DetailsPage/>
    </div>
  );
}

export default App;
